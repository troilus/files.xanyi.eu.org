*** General Notes ***

Things to know before asking questions :

----------------------------------------------------------------------
PROBLEMS WITH CHIRP :

I remind you that the attached module is experimental and not final, 
it may not be 100% compatible, but it is better than the original one.

----------------------------------------------------------------------
FIRST INSTALLATION

- Necessarily perform a VFO Reset (PTT + EXIT) on power-up.
- Enter the services menu (PTT + Side1) on power-up.
- Check menu settings:

———-Menu
	- menu ChDisp = NAME + FREQ
	- menu BLTIME = ... at you choose
	- menu BLMode = RXTX
	- menu BEEP = ... at you choose
	- menu TAILTE = ON
	- menu LMon = ON
	- menu DIG ID = OFF
	- menu DIGSRV = OFF  if you do not use selectives
	- menu BatSav = OFF
	- menu Satcom = OFF
	- menu UpConv = OFF

———- Services Menu
	- menu F LOCK = OFF
	- menu TXP EN = ON

----------------------------------------------------------------------
THE RADIO IS DEAF

If, despite the VFO reset, you have reception problems, check that:

- If you are coming from another kind of firmware, restore the backup of the original calibration file.

- The antenna is working (maybe try another one).

- If you are using a different type of antenna other than the classic grommet (telescopic antennas, external antennas, magnetic base, etc.) you must necessarily use filters or BP or NOTCH 88-108 otherwise you will worsen the listening experience.

- There are no nearby sources of interference (even a PC can generate strong signals).

Try adjusting the gain:

	- Disable dual watch.
	- Set to FM.
	- Put the radio in monitor, it is not important to receive some signal.
	- Long press key 1 (F must appear in the top line of the display).
	- Adjust the gain with the arrows, take the value to maximum and from there go down 10 points below.
	- Long press M key to store the value.


----------------------------------------------------------------------
I CAN'T ENTER THE FREQUENCY IT ALWAYS COMES BACK TO THE SAME VALUE

- This firmware is different from the others, it needs an extra digit on insertion e.g.: 145 000 0


----------------------------------------------------------------------
"TX DISABLE" APPEARS

- If you see it after the update you have not followed the installation procedure correctly (see above).
- With F + 6 keys you disable the transmission completely (check if you typed this sequence by mistake).


----------------------------------------------------------------------
THE SQUELCH ALWAYS REMAINS OPEN

- Be careful not to have set narrow filter N- , the squelch becomes more sensitive.
- There is probably a strong disturbance source nearby.


----------------------------------------------------------------------
THE RADIO IN RECEPTION WITH STRONG SIGNALS GOES INTERMITTENTLY

- Surely you have activated SATCOM... this should only be used for listening to weak signals, it cannot be switched on all the time.


----------------------------------------------------------------------
IN TRANSMISSION THE SCREEN BECOMES STRIPED

- It is an RF return problem (probable defective antenna or excessive proximity of body parts to the display).
  Can be resolved by disabling from MENU --> MICBAR = OFF


----------------------------------------------------------------------
I CAN'T SET THE AGC ALWAYS STAYS IN MAN (Manual)

- AGC slow and fast are exclusively for AM, DSB and CW, only in these modes can they be changed.
  In FM it remains exclusively fixed in MAN.



















